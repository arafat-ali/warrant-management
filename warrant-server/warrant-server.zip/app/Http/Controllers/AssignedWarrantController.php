<?php

namespace App\Http\Controllers;

use App\Models\AssinedWarrant;
use Illuminate\Http\Request;

class AssignedWarrantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AssinedWarrant  $assinedWarrant
     * @return \Illuminate\Http\Response
     */
    public function show(AssinedWarrant $assinedWarrant)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AssinedWarrant  $assinedWarrant
     * @return \Illuminate\Http\Response
     */
    public function edit(AssinedWarrant $assinedWarrant)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AssinedWarrant  $assinedWarrant
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AssinedWarrant $assinedWarrant)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AssinedWarrant  $assinedWarrant
     * @return \Illuminate\Http\Response
     */
    public function destroy(AssinedWarrant $assinedWarrant)
    {
        //
    }
}
